SPY dataset from https://www.algoseek.com/data-drive.html free sample data
IVE dataset from https://www.kibot.com/Historical_Data/SP_500_Historical_Tick_with_Bid_Ask_Data.aspx free sample data